#include "mbed.h"
#include "https_request.h"
#include "network-helper.h"
#include "ssl_ca_pem.h"
#include "stm32l475e_iot01_tsensor.h"
#include "stm32l475e_iot01_hsensor.h"

Serial pc(USBTX, USBRX);
float tmp_value = 0, humid_value = 0;

void dump_response(HttpResponse* res) {
    printf("Status: %d - %s\n", res->get_status_code(), res->get_status_message().c_str());

    printf("Headers:\n");
    for (size_t ix = 0; ix < res->get_headers_length(); ix++) {
        printf("\t%s: %s\n", res->get_headers_fields()[ix]->c_str(), res->get_headers_values()[ix]->c_str());
    }
    printf("\nBody (%lu bytes):\n\n%s\n", res->get_body_length(), res->get_body_as_string().c_str());
}

int main() {
    nsapi_error_t r;
    BSP_TSENSOR_Init();
    BSP_HSENSOR_Init();

    pc.printf("Starting\n");
    NetworkInterface* network = connect_to_default_network_interface();
    //if (!network) {
    //    printf("Cannot connect to the network, see serial output\n");
    //    return 1;
    //}

    TLSSocket* socket = new TLSSocket();

    if ((r = socket->open(network)) != NSAPI_ERROR_OK) {
        printf("TLS socket open failed (%d)\n", r);
        return 1;
    }

    if ((r = socket->set_root_ca_cert(SSL_CA_PEM)) != NSAPI_ERROR_OK) {
        printf("TLS socket set_root_ca_cert failed (%d)\n", r);
        return 1;
    }
    if ((r = socket->connect("https://nameless-hamlet-67722.herokuapp.com", 443)) != NSAPI_ERROR_OK) {
        printf("TLS socket connect failed (%d)\n", r);
        return 1;
    }

    while(1) {
        // POST request to herokuapp
        {
            HttpsRequest* post_temp = new HttpsRequest(socket, HTTP_POST, "https://nameless-hamlet-67722.herokuapp.com/temperature");
            post_temp->set_header("Content-Type", "application/json");
            post_temp->set_header("X-API-KEY", "ictes710-MbedDisco");
            char body[100];
            tmp_value = BSP_TSENSOR_ReadTemp();
            sprintf(body, "{\"data\":{\"temperature\": %.2f}}", tmp_value);
            //printf("%s\r\n", body);
            //const char body[] = "{\"data\":{\"temperature\": 22.20}}";
            HttpResponse* post_res = post_temp->send(body, strlen(body));
            if (!post_res) {
                printf("HttpRequest failed (error code %d)\n", post_temp->get_error());
                NVIC_SystemReset();
                return 1;
            }
            printf("\n----- HTTPS POST response -----\n");
            dump_response(post_res);
            delete post_temp;
        }
        {
            HttpsRequest* post_humid = new HttpsRequest(socket, HTTP_POST, "https://nameless-hamlet-67722.herokuapp.com/humidity");
            post_humid->set_header("Content-Type", "application/json");
            post_humid->set_header("X-API-KEY", "ictes710-MbedDisco");
            char body[100];
            humid_value = BSP_HSENSOR_ReadHumidity();
            sprintf(body, "{\"data\":{\"humidity\": %.2f}}", humid_value);
            HttpResponse* post_res = post_humid->send(body, strlen(body));
            if (!post_res) {
                printf("HttpRequest failed (error code %d)\n", post_humid->get_error());
                NVIC_SystemReset();
                return 1;
            }
            printf("\n----- HTTPS POST response -----\n");
            dump_response(post_res);
            delete post_humid;
        }
        // for surachai server
        {
            printf("\n----- HTTPS POST for surachai server -----\n");
            const char SSL_SURACHAI_SERVER[] =  "-----BEGIN CERTIFICATE-----\n"
            "MIIDxTCCAq2gAwIBAgIQAqxcJmoLQJuPC3nyrkYldzANBgkqhkiG9w0BAQUFADBs\n"
            "MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3\n"
            "d3cuZGlnaWNlcnQuY29tMSswKQYDVQQDEyJEaWdpQ2VydCBIaWdoIEFzc3VyYW5j\n"
            "ZSBFViBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTMxMTExMDAwMDAwMFowbDEL\n"
            "MAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3\n"
            "LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgSGlnaCBBc3N1cmFuY2Ug\n"
            "RVYgUm9vdCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMbM5XPm\n"
            "+9S75S0tMqbf5YE/yc0lSbZxKsPVlDRnogocsF9ppkCxxLeyj9CYpKlBWTrT3JTW\n"
            "PNt0OKRKzE0lgvdKpVMSOO7zSW1xkX5jtqumX8OkhPhPYlG++MXs2ziS4wblCJEM\n"
            "xChBVfvLWokVfnHoNb9Ncgk9vjo4UFt3MRuNs8ckRZqnrG0AFFoEt7oT61EKmEFB\n"
            "Ik5lYYeBQVCmeVyJ3hlKV9Uu5l0cUyx+mM0aBhakaHPQNAQTXKFx01p8VdteZOE3\n"
            "hzBWBOURtCmAEvF5OYiiAhF8J2a3iLd48soKqDirCmTCv2ZdlYTBoSUeh10aUAsg\n"
            "EsxBu24LUTi4S8sCAwEAAaNjMGEwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQF\n"
            "MAMBAf8wHQYDVR0OBBYEFLE+w2kD+L9HAdSYJhoIAu9jZCvDMB8GA1UdIwQYMBaA\n"
            "FLE+w2kD+L9HAdSYJhoIAu9jZCvDMA0GCSqGSIb3DQEBBQUAA4IBAQAcGgaX3Nec\n"
            "nzyIZgYIVyHbIUf4KmeqvxgydkAQV8GK83rZEWWONfqe/EW1ntlMMUu4kehDLI6z\n"
            "eM7b41N5cdblIZQB2lWHmiRk9opmzN6cN82oNLFpmyPInngiK3BD41VHMWEZ71jF\n"
            "hS9OMPagMRYjyOfiZRYzy78aG6A9+MpeizGLYAiJLQwGXFK3xPkKmNEVX58Svnw2\n"
            "Yzi9RKR/5CYrCsSXaQ3pjOLAEFe4yHYSkVXySGnYvCoCWw9E1CAx2/S6cCZdkGCe\n"
            "vEsXCS+0yx5DaMkHJ8HSXPfqIbloEpw8nL+e/IBcm2PN7EeqJSdnoDfzAIJ9VNep\n"
            "+OkuE6N36B9K\n"
            "-----END CERTIFICATE-----\n";

            HttpsRequest* post_req = new HttpsRequest(socket, SSL_SURACHAI_SERVER, HTTP_POST, "https://vast-temple-35112.herokuapp.com/push");
            post_req->set_header("Content-Type", "application/json");

            //float sensor_value_temp=12.3, sensor_value_hum=23.4;
            char body[100];
            sprintf(body, "{\"name\":\"%s\",\"temp\":\"%f\",\"humid\":\"%f\"}", "bank", tmp_value, humid_value);

            HttpResponse* post_res = post_req->send(body, strlen(body));
            if (!post_res) {
                printf("HttpRequest failed (error code %d)\n", post_req->get_error());
                return 1;
        }        
        wait(10);

    }

        socket->close();
        delete socket;


}

